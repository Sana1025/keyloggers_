import sys, os, json, platform
from datetime import datetime
from collections import defaultdict

import psutil

# Try optional import
try:
    import pefile
except Exception:
    pefile = None

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTableWidget, QTableWidgetItem, QPushButton,
    QVBoxLayout, QWidget, QHBoxLayout, QLabel, QFileDialog, QMessageBox, QHeaderView,
    QAbstractItemView, QTextEdit, QDialog, QDialogButtonBox
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QColor, QBrush

# ---------- Configuration ----------
WHITELIST = {
    "code.exe", "chrome.exe", "msedge.exe", "msedgewebview2.exe",
    "explorer.exe", "powershell.exe", "pwsh.exe", "cmd.exe",
    "teams.exe", "outlook.exe", "widget.exe", "onenote.exe", "spotify.exe",
}

TRUSTED_VENDORS = ["Microsoft", "Google", "Intel", "Adobe", "Mozilla", "Apple"]
SUSPICIOUS_KEYWORDS = ["keylog", "logger", "keyboard", "spy", "capture", "hook", "keycapture"]

# ---------- Helpers & heuristics ----------
def safe_str(x):
    try:
        return str(x)
    except Exception:
        return repr(x)

def score_reason_add(reasons, reason, points):
    reasons.append({"reason": reason, "points": points})

def is_signed_by_trusted_vendor(exe_path, trusted_vendors=None):
    """Best-effort: check if PE contains vendor names (uses pefile if available)."""
    if trusted_vendors is None:
        trusted_vendors = TRUSTED_VENDORS
    if not exe_path or not os.path.exists(exe_path):
        return False
    if platform.system() != "Windows":
        return False
    if pefile is None:
        return False
    try:
        pe = pefile.PE(exe_path, fast_load=True)
        try:
            if hasattr(pe, "DIRECTORY_ENTRY_SECURITY") and pe.DIRECTORY_ENTRY_SECURITY:
                sec = str(pe.DIRECTORY_ENTRY_SECURITY).lower()
                for v in trusted_vendors:
                    if v.lower() in sec:
                        return True
        except Exception:
            pass
        try:
            raw = pe.__data__[-65536:]
            raw_text = raw.decode("utf-8", errors="ignore").lower()
            for v in trusted_vendors:
                if v.lower() in raw_text:
                    return True
        except Exception:
            pass
    except Exception:
        return False
    return False

def linux_check_input_handles(pid):
    try:
        proc = psutil.Process(pid)
        for f in proc.open_files():
            if f.path.startswith("/dev/input/event"):
                return True
        fd_dir = f"/proc/{pid}/fd"
        if os.path.isdir(fd_dir):
            for name in os.listdir(fd_dir):
                try:
                    target = os.readlink(os.path.join(fd_dir, name))
                    if target.startswith("/dev/input/event"):
                        return True
                except Exception:
                    continue
    except Exception:
        return False
    return False

def scan_windows_autostart():
    res = []
    if platform.system() != "Windows":
        return res
    try:
        import winreg
        RUN_PATHS = [
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
        ]
        for hive, path in RUN_PATHS:
            try:
                with winreg.OpenKey(hive, path) as k:
                    i = 0
                    while True:
                        try:
                            name, val, _ = winreg.EnumValue(k, i)
                            res.append({"hive": "HKCU" if hive==winreg.HKEY_CURRENT_USER else "HKLM",
                                        "path": path, "name": name, "value": val})
                            i += 1
                        except OSError:
                            break
            except OSError:
                continue
    except Exception:
        pass
    return res

def linux_autostart_entries():
    entries = []
    paths = [os.path.expanduser("~/.config/autostart"), "/etc/xdg/autostart"]
    for p in paths:
        if os.path.isdir(p):
            for fn in os.listdir(p):
                if fn.endswith(".desktop"):
                    try:
                        full = os.path.join(p, fn)
                        with open(full, "r", errors="ignore") as f:
                            content = f.read()
                        entries.append({"path": full, "content_snippet": content[:400]})
                    except Exception:
                        continue
    return entries

def severity_from_score(score):
    if score >= 8: return "high"
    if score >= 4: return "medium"
    return "low"

def scan_process(proc):
    info = {
        "pid": proc.pid,
        "name": safe_str(proc.name()),
        "exe": "",
        "cmdline": [],
        "user": "",
        "connections": [],
        "score": 0,
        "reasons": [],
        "severity": "low",
    }
    try:
        info["exe"] = safe_str(proc.exe()) if proc.is_running() else ""
    except Exception:
        info["exe"] = ""
    try:
        info["cmdline"] = proc.cmdline() if proc.is_running() else []
    except Exception:
        info["cmdline"] = []
    try:
        info["user"] = safe_str(proc.username()) if proc.is_running() else ""
    except Exception:
        info["user"] = ""

    system = platform.system()

    # Network connections (use net_connections)
    try:
        conns = proc.net_connections(kind="inet")
        for c in conns:
            laddr = f"{getattr(c.laddr, 'ip', '')}:{getattr(c.laddr, 'port', '')}" if c.laddr else ""
            raddr = f"{getattr(c.raddr, 'ip', '')}:{getattr(c.raddr, 'port', '')}" if c.raddr else ""
            info["connections"].append({"laddr": laddr, "raddr": raddr, "status": safe_str(c.status)})
        if len(info["connections"]) >= 5:
            score_reason_add(info["reasons"], f"Has many ({len(info['connections'])}) active network connections.", 2)
            info["score"] += 2
    except Exception:
        pass

    # Keyword heuristics
    cl = " ".join(info["cmdline"]).lower() if info["cmdline"] else ""
    name = (info["name"] or "").lower()
    exe = (info["exe"] or "").lower()
    for token in SUSPICIOUS_KEYWORDS:
        if token in cl or token in name or token in exe:
            score_reason_add(info["reasons"], f"Suspicious token '{token}' in name/cmdline/path.", 3)
            info["score"] += 3
            break

    # Platform-specific
    if system == "Windows":
        try:
            if exe and is_signed_by_trusted_vendor(exe):
                info["reasons"].append({"reason": "Signed by trusted vendor", "points": 0})
                info["severity"] = "low"
                return info
        except Exception:
            pass
    elif system == "Linux":
        if linux_check_input_handles(proc.pid):
            score_reason_add(info["reasons"], "Holds handle to /dev/input/event* device.", 5)
            info["score"] += 5

    info["severity"] = severity_from_score(info["score"])
    return info

# ---------- Background scanner thread ----------
class ScannerThread(QThread):
    finished_signal = pyqtSignal(dict)
    progress_signal = pyqtSignal(str)

    def run(self):
        system = platform.system()
        results = {"platform": system, "processes": [], "autostart": {}, "summary": {}}
        self.progress_signal.emit("Enumerating processes...")
        procs = list(psutil.process_iter(attrs=[], ad_value=None))
        for p in procs:
            try:
                pname = ""
                try:
                    pname = (p.name() or "").lower()
                except Exception:
                    pname = ""
                if pname in WHITELIST:
                    continue
                info = scan_process(p)
                # Double-check signatures on Windows
                if info.get("exe") and info.get("severity") != "high":
                    if platform.system() == "Windows" and is_signed_by_trusted_vendor(info.get("exe")):
                        info["score"] = 0
                        info["reasons"] = [{"reason": "Signed by trusted vendor", "points": 0}]
                        info["severity"] = "low"
                results["processes"].append(info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            except Exception:
                continue

        # autostart
        if system == "Windows":
            results["autostart"]["windows_run"] = scan_windows_autostart()
        elif system == "Linux":
            results["autostart"]["linux_autostart"] = linux_autostart_entries()

        # summary
        sev_counts = defaultdict(int)
        for proc in results["processes"]:
            sev_counts[proc["severity"]] += 1
        results["summary"] = {
            "total_processes": len(results["processes"]),
            "severity_counts": dict(sev_counts),
            "high_confidence_hits": [p for p in results["processes"] if p["severity"] == "high"]
        }

        self.finished_signal.emit(results)

# ---------- GUI ----------
class DetailDialog(QDialog):
    def __init__(self, proc_info, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Details - PID {proc_info.get('pid')}")
        self.resize(700, 420)
        layout = QVBoxLayout()
        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(json.dumps(proc_info, indent=2, ensure_ascii=False))
        layout.addWidget(txt)
        btns = QDialogButtonBox(QDialogButtonBox.Close)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self.setLayout(layout)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Keylogger Detector — GUI")
        self.resize(1100, 600)
        self.results = None

        # Widgets
        central = QWidget()
        self.setCentralWidget(central)
        vbox = QVBoxLayout(central)

        top_controls = QHBoxLayout()
        self.scan_btn = QPushButton("Scan Now")
        self.scan_btn.clicked.connect(self.start_scan)
        top_controls.addWidget(self.scan_btn)

        self.save_txt_btn = QPushButton("Save report.txt")
        self.save_txt_btn.clicked.connect(self.save_report_txt)
        self.save_txt_btn.setEnabled(False)
        top_controls.addWidget(self.save_txt_btn)

        self.save_json_btn = QPushButton("Save report.json")
        self.save_json_btn.clicked.connect(self.save_report_json)
        self.save_json_btn.setEnabled(False)
        top_controls.addWidget(self.save_json_btn)

        self.open_suspicious_btn = QPushButton("Open suspicious_log.txt")
        self.open_suspicious_btn.clicked.connect(self.open_suspicious_log)
        top_controls.addWidget(self.open_suspicious_btn)

        top_controls.addStretch()
        self.status_label = QLabel("Ready")
        top_controls.addWidget(self.status_label)

        vbox.addLayout(top_controls)

        # Table
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["PID","Name","Path","Score","Severity","Reasons","#Conns"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.doubleClicked.connect(self.table_double_click)
        vbox.addWidget(self.table)

        self.thread = None

    def start_scan(self):
        self.scan_btn.setEnabled(False)
        self.save_txt_btn.setEnabled(False)
        self.save_json_btn.setEnabled(False)
        self.table.setRowCount(0)
        self.status_label.setText("Scanning...")
        self.thread = ScannerThread()
        self.thread.progress_signal.connect(self.show_status)
        self.thread.finished_signal.connect(self.scan_finished)
        self.thread.start()

    def show_status(self, txt):
        self.status_label.setText(txt)

    def scan_finished(self, results):
        self.results = results
        self.populate_table(results)
        self.status_label.setText(f"Scan complete — {results['summary']['total_processes']} processes")
        self.scan_btn.setEnabled(True)
        self.save_txt_btn.setEnabled(True)
        self.save_json_btn.setEnabled(True)

    def populate_table(self, results):
        procs = sorted(results["processes"], key=lambda x: x.get("score",0), reverse=True)
        self.table.setRowCount(len(procs))
        for r, proc in enumerate(procs):
            self.table.setItem(r, 0, QTableWidgetItem(str(proc.get("pid",""))))
            self.table.setItem(r, 1, QTableWidgetItem(str(proc.get("name",""))))
            self.table.setItem(r, 2, QTableWidgetItem(str(proc.get("exe",""))))
            self.table.setItem(r, 3, QTableWidgetItem(str(proc.get("score",""))))
            self.table.setItem(r, 4, QTableWidgetItem(str(proc.get("severity",""))))
            reasons = ", ".join([f"{r['reason']}(+{r['points']})" for r in proc.get("reasons",[])]) or ""
            item_reasons = QTableWidgetItem(reasons)
            item_reasons.setToolTip(reasons)
            self.table.setItem(r, 5, item_reasons)
            self.table.setItem(r, 6, QTableWidgetItem(str(len(proc.get("connections",[])))))

            # color by severity
            severity = proc.get("severity","low")
            if severity == "high":
                color = QBrush(QColor(255,200,200))
            elif severity == "medium":
                color = QBrush(QColor(255,235,180))
            else:
                color = QBrush(QColor(240,255,240))
            for c in range(self.table.columnCount()):
                self.table.item(r, c).setBackground(color)

    def table_double_click(self, index):
        row = index.row()
        if not self.results:
            return
        procs = sorted(self.results["processes"], key=lambda x: x.get("score",0), reverse=True)
        if 0 <= row < len(procs):
            dlg = DetailDialog(procs[row], parent=self)
            dlg.exec_()

    def save_report_txt(self):
        if not self.results:
            QMessageBox.information(self, "No results","Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save text report", "report.txt", "Text files (*.txt);;All files (*)")
        if not path:
            return
        lines = []
        system = self.results.get("platform","")
        lines.append(f"Keylogger Detection Tool — Platform: {system}")
        lines.append(f"Total processes scanned: {self.results['summary'].get('total_processes',0)}")
        lines.append(f"Severity counts: {self.results['summary'].get('severity_counts',{})}")
        lines.append("")
        lines.append("Top suspicious processes:")
        procs = sorted(self.results["processes"], key=lambda x: x.get("score",0), reverse=True)
        for proc in procs:
            if proc.get("score",0) <= 0:
                continue
            lines.append("-"*70)
            lines.append(f"PID {proc['pid']}  {proc['name']}  (score={proc['score']}, severity={proc['severity']})")
            lines.append(f"exe: {proc.get('exe','')}")
            if proc.get("cmdline"):
                lines.append("cmd: " + " ".join(proc.get("cmdline"))[:400])
            for r in proc.get("reasons",[]):
                lines.append(f"  • {r['reason']} (+{r.get('points',0)})")
            if proc.get("connections"):
                lines.append(f"  net connections: {len(proc.get('connections',[]))}")
        lines.append("")
        if platform.system() == "Windows":
            entries = self.results["autostart"].get("windows_run",[])
            lines.append(f"Windows Run entries ({len(entries)}):")
            for e in entries:
                lines.append(f"  [{e['hive']} {e['path']}] {e['name']} => {e['value']}")
        elif platform.system() == "Linux":
            entries = self.results["autostart"].get("linux_autostart",[])
            lines.append(f"Linux autostart entries ({len(entries)}):")
            for e in entries:
                lines.append(f"  {e['path']}")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            QMessageBox.information(self, "Saved", f"Saved to {path}")
        except Exception as ex:
            QMessageBox.critical(self, "Error", f"Failed to save: {ex}")

    def save_report_json(self):
        if not self.results:
            QMessageBox.information(self, "No results","Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save JSON report", "report.json", "JSON files (*.json);;All files (*)")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.results, f, indent=2)
            QMessageBox.information(self, "Saved", f"Saved to {path}")
        except Exception as ex:
            QMessageBox.critical(self, "Error", f"Failed to save: {ex}")

    def open_suspicious_log(self):
        p = os.path.join(os.getcwd(), "suspicious_log.txt")
        if not os.path.exists(p):
            QMessageBox.information(self, "No log", "suspicious_log.txt not found (no medium/high entries logged yet).")
            return
        try:
            if platform.system() == "Windows":
                os.startfile(p)
            else:
                # generic open
                import subprocess
                subprocess.run(["xdg-open" if platform.system()=="Linux" else "open", p])
        except Exception as ex:
            QMessageBox.critical(self, "Error", f"Could not open file: {ex}")

# ---------- App entry ----------
def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
