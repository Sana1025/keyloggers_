import sys
import os
import json
import psutil
import hashlib
import socket
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton,
    QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox, QLabel
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal

# --------------------------
# Helper functions
# --------------------------
def get_hash(file_path, algo="sha256"):
    h = hashlib.new(algo)
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None

def score_reason_add(reasons, reason, score):
    reasons.append(reason)
    return score

# Known suspicious keywords
SUSPICIOUS_KEYWORDS = ["keylogger", "stealer", "logger", "sniffer", "spy"]

# --------------------------
# Process scanning logic
# --------------------------
def scan_process(proc):
    info = {
        "pid": proc.pid,
        "name": "",
        "exe": "",
        "cmdline": [],
        "connections": [],
        "hash": None,
        "score": 0,
        "reasons": [],
    }
    try:
        info["name"] = proc.name()
        info["exe"] = proc.exe()
        info["cmdline"] = proc.cmdline()
    except Exception:
        pass

    try:
        conns = proc.net_connections(kind="inet")
        for c in conns:
            if c.raddr:
                info["connections"].append((c.raddr.ip, c.raddr.port))
                info["score"] += score_reason_add(info["reasons"],
                    f"Has external connection to {c.raddr.ip}:{c.raddr.port}", 5)
    except Exception:
        pass

    if info["exe"] and os.path.exists(info["exe"]):
        h = get_hash(info["exe"])
        if h:
            info["hash"] = h

    # Keyword heuristics (safe handling of cmdline)
    cl = " ".join(info["cmdline"]) if isinstance(info["cmdline"], list) else ""
    cl = cl.lower()
    name = (info["name"] or "").lower()
    exe = (info["exe"] or "").lower()
    for token in SUSPICIOUS_KEYWORDS:
        if token in cl or token in name or token in exe:
            info["score"] += score_reason_add(info["reasons"],
                f"Suspicious token '{token}' in name/cmdline/path.", 3)
            break

    return info

# --------------------------
# Background thread
# --------------------------
class ScannerThread(QThread):
    finished = pyqtSignal(dict)

    def run(self):
        results = []
        for proc in psutil.process_iter():
            try:
                pinfo = scan_process(proc)
                results.append(pinfo)
            except Exception:
                continue

        summary = {
            "total_processes": len(results),
            "severity_counts": {"low":0, "medium":0, "high":0},
        }
        for r in results:
            if r["score"] >= 8:
                summary["severity_counts"]["high"] += 1
            elif r["score"] >= 3:
                summary["severity_counts"]["medium"] += 1
            else:
                summary["severity_counts"]["low"] += 1

        self.finished.emit({"results": results, "summary": summary})

# --------------------------
# Main Window
# --------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Keylogger Detector")
        self.resize(1000, 600)

        self.results = []

        layout = QVBoxLayout()
        self.status_label = QLabel("Status: Ready")
        layout.addWidget(self.status_label)

        self.scan_btn = QPushButton("Scan Processes")
        self.scan_btn.clicked.connect(self.start_scan)
        layout.addWidget(self.scan_btn)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["PID", "Name", "Executable", "Connections", "Score", "Reasons"])
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        self.save_txt_btn = QPushButton("Save Report (TXT)")
        self.save_txt_btn.clicked.connect(lambda: self.save_report("txt"))
        self.save_txt_btn.setEnabled(False)
        layout.addWidget(self.save_txt_btn)

        self.save_json_btn = QPushButton("Save Report (JSON)")
        self.save_json_btn.clicked.connect(lambda: self.save_report("json"))
        self.save_json_btn.setEnabled(False)
        layout.addWidget(self.save_json_btn)

        # Summary label at bottom
        self.summary_label = QLabel("Summary: No scan yet")
        layout.addWidget(self.summary_label)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def start_scan(self):
        self.status_label.setText("Status: Scanning...")
        self.scan_btn.setEnabled(False)
        self.thread = ScannerThread()
        self.thread.finished.connect(self.scan_finished)
        self.thread.start()

    def scan_finished(self, results):
        self.results = results
        self.populate_table(results)
        total = results['summary']['total_processes']
        sev_counts = results['summary']['severity_counts']
        self.status_label.setText(f"Scan complete — {total} processes")
        self.summary_label.setText(f"Summary: {sev_counts}")
        self.scan_btn.setEnabled(True)
        self.save_txt_btn.setEnabled(True)
        self.save_json_btn.setEnabled(True)

    def populate_table(self, results):
        res = results["results"]
        self.table.setRowCount(len(res))
        for row, r in enumerate(res):
            self.table.setItem(row, 0, QTableWidgetItem(str(r["pid"])))
            self.table.setItem(row, 1, QTableWidgetItem(r["name"]))
            self.table.setItem(row, 2, QTableWidgetItem(r["exe"]))
            conns = ", ".join([f"{ip}:{port}" for ip, port in r["connections"]])
            self.table.setItem(row, 3, QTableWidgetItem(conns))
            self.table.setItem(row, 4, QTableWidgetItem(str(r["score"])))
            self.table.setItem(row, 5, QTableWidgetItem("; ".join(r["reasons"])))

    def save_report(self, fmt):
        if not self.results:
            QMessageBox.warning(self, "Warning", "No results to save!")
            return
        options = QFileDialog.Options()
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Report", "report."+fmt,
            "Text Files (*.txt);;JSON Files (*.json)", options=options)
        if not path:
            return
        try:
            if fmt == "txt":
                with open(path, "w", encoding="utf-8") as f:
                    f.write("Keylogger Detection Report\n")
                    f.write("Generated: "+str(datetime.now())+"\n\n")
                    for r in self.results["results"]:
                        f.write(f"PID: {r['pid']} Name: {r['name']} Score: {r['score']}\n")
                        f.write("Reasons: "+"; ".join(r["reasons"]) + "\n\n")
                    f.write("Summary: "+str(self.results["summary"])+"\n")
            else:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(self.results, f, indent=2)
            QMessageBox.information(self, "Saved", f"Report saved to {path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

# --------------------------
# Main entry
# --------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())